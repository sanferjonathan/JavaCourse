package sample;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Pedestrian {

    private boolean alive = true, side;
    private int r, id;
    private double xCenter, yCenter, velX = 0, velY = 0;
    private List<Pedestrian> threats = new ArrayList<>();


    public Pedestrian(double x, double y, int r, int id, boolean side){
        this.id = id;
        this.xCenter = x-(r/2);
        this.yCenter = y-(r/2);
        this.r = r;
        this.side = side;
    }

    public void update(){
        this.xCenter += this.velX;
        this.yCenter += this.velY;
    }

    public double getXCenter(){
        return xCenter;
    }

    public boolean getSide(){
        return side;
    }

    public boolean isAlive(){
        return alive;
    }

    public void kill(){
        alive = false;
    }

    public void drawCenteredCircle(GraphicsContext g, Pedestrian pedestrian) {
        if(pedestrian.getSide()){
            g.getCanvas().getGraphicsContext2D().setFill(Color.BLUE);
        }
        else{
            g.getCanvas().getGraphicsContext2D().setFill(Color.RED);
        }
        g.fillOval(xCenter, yCenter,r,r);
    }

    public BBox bBox(){
        return new BBox(xCenter, yCenter, r, id);
    }
    //gather all potential threats within 100 units in a list
    public void scan(Pedestrian other, boolean value){
        if(distanceCheck(other) < 100){
            this.threats.add(other);
        }
        if(value){
            distinguishThreat();
            this.threats.clear();
        }
        else{
            defaultVelocity();
        }
        System.out.println(this.threats.size());
    }

    public void defaultVelocity(){
        if(this.side){
            velX = 1.0;
            velY = 0;
        }
        else if(!this.side){
            velX = -1.0;
            velY = 0;
        }
    }

    public void distinguishThreat(){
        for(Pedestrian threat : threats){
            if(this.side != threat.side && this.side == true){//Blue
                blueVsRed(threat);
                //blueVsBlue(threat);
            }
            else if((this.side != threat.side && this.side == false)){//Red
                redVsBlue(threat);
            }
        }
    }

    public void blueVsRed(Pedestrian threat){
        if(threat.yCenter <= this.yCenter
                && this.yCenter <= threat.yCenter + 20){
            velX = 0.5;
            velY = 0.5;
        }
        else if(threat.yCenter >= this.yCenter
                && this.yCenter >= threat.yCenter - 20){
            velX = 0.5;
            velY = -0.5;
        }
        else {
            velX = 1.0;
            velY = 0;
        }
    }

    public void redVsBlue(Pedestrian threat){
        if(threat.yCenter >= this.yCenter
                && this.yCenter >= threat.yCenter - 20){
            velX = -0.5;
            velY = -0.5;
        }
        else if(threat.yCenter <= this.yCenter
                && this.yCenter <= threat.yCenter + 20){
            velX = -0.5;
            velY = 0.5;
        }
        else {
            velX = -1.0;
            velY = 0;
        }
    }

    public void blueVsBlue(Pedestrian threat){
        if(threat.yCenter <= this.yCenter
                && this.yCenter <= threat.yCenter + 40){
            velX = 0.5;
            velY = 0.5;
            if(threat.yCenter <= this.yCenter - 40){
                velX = 0.5;
                velY = -0.5;
            }
        }
        else if(threat.yCenter >= this.yCenter
                && this.yCenter >= threat.yCenter - 40){
            velX = 0.5;
            velY = -0.5;
            if(threat.yCenter >= this.yCenter + 40){
                velX = 0.5;
                velY = 0.5;
            }
        }
        else {
            velX = 1.0;
            velY = 0;
        }
    }

    public double minDistance(){
        double temp, min = 100;
        for(Pedestrian threat : threats){
            temp = distanceCheck(threat);
            if(temp < min){
                min = temp;
            }
        }
        return min;
    }

    public double distanceCheck(Pedestrian threat){
        return Math.sqrt(Math.pow(this.xCenter - threat.xCenter, 2) +
                Math.pow(this.yCenter - threat.yCenter, 2));
    }

    public void removeThreat(){
        Iterator<Pedestrian> iterator = this.threats.iterator();
        while (iterator.hasNext()){
            if(distanceCheck(iterator.next()) > 100){
                iterator.remove();
            }
        }
    }

    public boolean isColliding(Pedestrian other){
        return bBox().isColliding(other.bBox());
    }
}
